make
/a.out "/home/piyush/Downloads/y-cruncher v0.7.8.9507-static/y-cruncher" "/home/piyush/Desktop/vishal/assignments/sem_6/col331_os/lab2/2018CS50426/bin/mainfile" 1 8
make clean

Results are stored in result.txt
