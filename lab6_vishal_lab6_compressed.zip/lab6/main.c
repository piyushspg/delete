#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>

#define ll long long

int main(int argc, char *argv[])
{
	if(argc != 5) {
      printf("arguments: y-cruncher_binary assign_2_binary n_j threads\n");
      // (for how many rams you want to do the test)
      exit(1);
   	}
   	
   	char *y_cruncher_loc = argv[1];
   	char *assign_2_binary = argv[2];
    int n_j = atoi(argv[3]);	
    int threads = atoi(argv[4]);	
 	double time_spent[3][15];


    for (int i=0; i<=1; i++) {
    	switch(i) {
    		case 0: {printf("single core y-cruncher benchmarking\n");break;}
    		case 1: {printf("multi core y-cruncher benchmarking\n");break;}
    	}
    	// i=0 for single core and i=1 for multi-core
    	for (int j=1; j<=n_j; j++) {
    		FILE *fptr;
			fptr = fopen("./inp.txt","w");
			if(fptr == NULL) {
			  printf("Error opening file!");   
			  exit(1);             
			}
			fprintf(fptr,"%d\n%d\n%d\n\n", 0, i, j);
			fclose(fptr);
			
			time_spent[i][j] = 0.0;
			
			struct timeval  tv1, tv2;
			gettimeofday(&tv1, NULL);

		    printf("starting i=%d j=%d\n", i, j);
		    char command[200];
		    sprintf(command,  "\"%s\" < ./inp.txt > out/out_%d_%d.txt", y_cruncher_loc, i, j);
			system(command);
			
			gettimeofday(&tv2, NULL);
			
			time_spent[i][j] = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);
			printf("complete. Took %f sec\n", time_spent[i][j]);
    	}
    }
    
    printf("multi core assignment 2 program\n");
    for (int j=1; j<=5; j++) {
		
		time_spent[2][j] = 0.0;
		
		struct timeval  tv1, tv2;
		gettimeofday(&tv1, NULL);
		
		ll N = (ll)1000*(ll)(pow(10, j));

	    printf("starting N=%lld\n", N);
	    char command[200];
	    sprintf(command,  "\"%s\" %lld %d out", assign_2_binary, N, threads);
		system(command);
		
		gettimeofday(&tv2, NULL);
		
		time_spent[2][j] = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);
		printf("complete. Took %f sec\n", time_spent[2][j]);
	}
    
    FILE *fptr;
	fptr = fopen("./results.txt","w");
	if(fptr == NULL) {
	  printf("Error opening file!");   
	  exit(1);             
	}
	for (int i=0; i<=1; i++) {
    	switch(i) {
    		case 0: {fprintf(fptr, "single core y-cruncher benchmarking\n");break;}
    		case 1: {fprintf(fptr, "multi core y-cruncher benchmarking\n");break;}
    	}
    	// i=0 for single core and i=1 for multi-core
    	for (int j=1; j<=n_j; j++) {
    		fprintf(fptr, "n_j=%d %f sec\n", j, time_spent[i][j]);
    	}
	}
	fprintf(fptr, "multi core assignment 2 program\n");
	for (int j=1; j<=5; j++) {
		ll N = (ll)1000*(ll)(pow(10, j));
		fprintf(fptr, "N=%lld %f sec\n", N, time_spent[2][j]);
	}
	fclose(fptr);
    return 0;
}
